package ai.amani.speechverifier.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Immutable configuration of a speech-verification session, assembled by
 * [ai.amani.speechverifier.SpeechVerifier.Builder] and delivered to the fragment.
 *
 * The language is always Turkish (the bundled Vosk model) and the session video is always
 * recorded — neither is configurable.
 *
 * @param steps             Ordered verification steps. Each is either a spoken passphrase or a
 *                          knowledge-based identity question; the list order is the flow order
 *                          and a repeated step runs again (re-randomising its pick). Built from
 *                          `speechText(...)` when the integrator uses the simple single-text API.
 * @param verificationExemptWords Words shown but EXCLUDED from verification (brand names,
 *                          acronyms the Turkish model can't transcribe).
 * @param autoDetectForeignWords When true (default), non-Turkish-looking words are auto-exempted.
 * @param detectTurkishNegation When true (default), an added Turkish negation ("onaylamıyorum"
 *                          for "onaylıyorum") fails the step regardless of similarity.
 * @param rejectWords       Words/phrases that fail the step if spoken (extra negatives, "hayır",
 *                          "iptal", …) — complements the automatic negation guard.
 * @param ignoreTurkishDiacritics When true, Turkish letters are folded to ASCII (ş→s, ç→c, ğ→g,
 *                          ı/İ→i, ö→o, ü→u, â/î/û→a/i/u) on both the target and the
 *                          transcription before matching. Off by default (strict Turkish).
 * @param timeoutMs         Time window (ms) per step before the flow fails.
 * @param continuationPrompts On-screen prompt overrides for the identity questions.
 * @param uiColors          Colour overrides.
 * @param uiTexts           Text overrides.
 * @param bottomSheetCornerRadiusDp Top corner radius (dp) of the bottom sheet panel behind the
 *                          texts. 0 (default) keeps square corners.
 */
@Parcelize
data class SpeechVerifierConfig(
    var speechText: String = "",
    var steps: List<VerificationStep> = emptyList(),
    var verificationExemptWords: List<String> = emptyList(),
    var autoDetectForeignWords: Boolean = true,
    var detectTurkishNegation: Boolean = true,
    var rejectWords: List<String> = emptyList(),
    var ignoreTurkishDiacritics: Boolean = false,
    var timeoutMs: Long = 60_000L,
    var continuationPrompts: ContinuationPrompts = ContinuationPrompts(),
    var uiColors: SpeechVerifierUIColors = SpeechVerifierUIColors(),
    var uiTexts: SpeechVerifierUITexts = SpeechVerifierUITexts(),
    var bottomSheetCornerRadiusDp: Float = 0f,
) : Parcelable {
    companion object {
        /** Fallback post-match capture delay (ms) when an item (phrase/question) sets none. */
        const val DEFAULT_SUCCESS_CAPTURE_DELAY_MS = 500L
    }
}
