package ai.amani.speechverifier

import ai.amani.speechverifier.data.network.SpeechVerifierApi
import ai.amani.speechverifier.data.repository.VerificationUploadRepositoryImpl
import ai.amani.speechverifier.data.storage.InternalSecureVideoStorage
import ai.amani.speechverifier.domain.model.CustomerProfile
import ai.amani.speechverifier.domain.usecase.UploadSpeechVerificationUseCase
import ai.amani.speechverifier.model.ContinuationPrompts
import ai.amani.speechverifier.model.SpeechVerifierConfig
import ai.amani.speechverifier.model.SpeechVerifierUIColors
import ai.amani.speechverifier.model.SpeechVerifierUiState
import ai.amani.speechverifier.model.SpeechVerifierUploadError
import ai.amani.speechverifier.model.VerificationStep
import ai.amani.speechverifier.observable.SpeechVerifierObserver
import ai.amani.speechverifier.observable.SpeechVerifierUploadObserver
import ai.amani.speechverifier.ui.SpeechVerifierFragment
import android.content.Context
import android.os.Bundle
import androidx.annotation.ColorInt
import androidx.annotation.ColorRes
import androidx.fragment.app.Fragment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Entry point of the standalone speech-verification module.
 *
 * Presents a camera screen showing a text the user must read aloud. The on-device speech
 * recognizer verifies an exact match live while a video of the session is recorded and, on
 * success, moved into the app-private secure folder; then [SpeechVerifierObserver.onSuccess]
 * fires and the fragment removes itself.
 *
 * This module is fully self-contained — it does not depend on the core AmaniAi SDK, so adding
 * it does not change the size or dependencies of AmaniAi. It is published as the separate
 * artifact `ai.amani.android:amani-speech-verifier`.
 *
 * ```kotlin
 * val fragment = SpeechVerifier.Builder()
 *     .documentType("XXX_ST_0")
 *     .speechText("Onaylıyorum")
 *     .session(serverURL = "https://…", token = profileScopedJwt)
 *     .observe(myObserver)
 *     .build()
 * ```
 */
object SpeechVerifier {

    // Written by build(), read by the upload flow.
    internal var operationID: String = ""
    internal var docType: String = "XXX_ST_0"

    // Upload session credentials — set via Builder.session(...). Kept out of the Parcelable
    // fragment config on purpose (the token must never enter a Bundle) and never logged.
    internal var serverUrl: String? = null
    internal var sessionToken: String? = null

    // Identity-question answers supplied directly via Builder.identityAnswers(...), the opt-in
    // alternative to fetching them from the documents endpoint. Committed by build() (from the
    // builder instance) so each flow gets exactly the answers configured on its own builder — or
    // null, which routes identity questions back to the network fetch. This is PII, so like the
    // token it is kept out of the Parcelable config/Bundle and never logged.
    internal var providedProfile: CustomerProfile? = null

    // Absolute path of the last session's secured recording. Written by the ViewModel right
    // after the secure move succeeds; consumed by upload() so the app never has to hand the
    // path back. Reset by build() so a stale recording can't leak into a new session.
    internal var lastSecuredVideoPath: String? = null

    // Soft remote logging opt-in (default OFF). Set via Builder.remoteLogging(...) and committed
    // by build(). When on AND session(...) credentials are present, the flow posts lightweight
    // process signposts + errors to the same client_logs endpoint the core SDK uses.
    internal var loggingEnabled: Boolean = false

    // Voice Assistant (TTS) base URL — OPTIONAL. If set via Builder.voiceUrl(...) it is used
    // directly; if left null the module fetches it from the app config itself
    // (company/{id}/config/app → general_configs.ttsVoices_android). Kept out of the Parcelable
    // config/Bundle like the other URLs. Only used when config.voiceAssistantEnabled is on.
    internal var voiceUrl: String? = null

    fun Builder(): SpeechVerifierBuilder = SpeechVerifierBuilder()

    /**
     * Uploads the recorded video of the last completed session and reports the backend's
     * evaluation of it.
     *
     * What happens:
     *  1. A static 80×80 black placeholder image (generated at runtime) + the recorded video
     *     are POSTed to the Amani `document` endpoint in one multipart request — the same
     *     wire format the core SDK's pose-estimation selfie uses with video recording
     *     enabled (image in `pages`, video in `videos`, `upload_source=Kyc`, `profile`
     *     parsed from the JWT).
     *  2. The SSE profile event stream is then observed until the backend pushes the step
     *     status for this upload (`step_results` / `validation_result`).
     *  3. [SpeechVerifierUploadObserver.onResult] delivers that step status (e.g. `APPROVED`,
     *     `PENDING_REVIEW`, `REJECTED`) — always on the main thread.
     *
     * The recorded video is tracked internally: the module secures it at the end of the flow
     * and remembers its path, so nothing needs to be handed back — just call `upload(...)`
     * after [SpeechVerifierObserver.onSuccess].
     *
     * Requires [SpeechVerifierBuilder.session] to have been configured; the token must be a
     * profile-scoped JWT (carrying the `profile_id` claim) or the event stream rejects it.
     *
     * @param context any context — only its applicationContext is retained.
     * @param observer result callback (main thread).
     * @param timeoutMs how long to wait for the backend's evaluation after the upload
     *   (default 60s). On expiry [SpeechVerifierUploadObserver.onError] fires with
     *   `RESULT_TIMEOUT` — the document itself was already uploaded.
     * @throws IllegalStateException if `session(serverURL, token)` was never provided.
     */
    @JvmOverloads
    fun upload(
        context: Context,
        observer: SpeechVerifierUploadObserver,
        timeoutMs: Long = DEFAULT_UPLOAD_RESULT_TIMEOUT_MS
    ) {
        val server = serverUrl
        val token = sessionToken
        check(!server.isNullOrBlank() && !token.isNullOrBlank()) {
            "SpeechVerifier.upload() needs session credentials — call " +
                    "SpeechVerifier.Builder().session(serverURL, token) before building the flow."
        }

        val videoFilePath = lastSecuredVideoPath
        if (videoFilePath.isNullOrBlank()) {
            observer.onError(
                SpeechVerifierUploadError.SESSION_MISSING,
                "No secured recording found — upload() must be called after a session " +
                        "completed successfully (SpeechVerifierObserver.onSuccess)."
            )
            return
        }

        // Composition root of the upload action: bind the domain interfaces to their
        // data-layer implementations, then run the pure use case.
        val appContext = context.applicationContext
        val useCase = UploadSpeechVerificationUseCase(
            uploadRepository = VerificationUploadRepositoryImpl(
                context = appContext,
                api = SpeechVerifierApi(serverUrl = server, token = token)
            ),
            secureStorage = InternalSecureVideoStorage(appContext)
        )

        // One-shot, self-contained job: no global connection state survives past the callback.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            val outcome = useCase(
                docType = docType,
                operationID = operationID,
                videoFilePath = videoFilePath,
                timeoutMs = timeoutMs
            )
            withContext(Dispatchers.Main) {
                when (outcome) {
                    is UploadSpeechVerificationUseCase.UploadOutcome.Success ->
                        observer.onResult(outcome.result)
                    is UploadSpeechVerificationUseCase.UploadOutcome.Failure ->
                        observer.onError(outcome.error, outcome.message)
                }
            }
        }
    }

    private const val DEFAULT_UPLOAD_RESULT_TIMEOUT_MS = 60_000L

    /** Builder of the speech-verification fragment. [speechText] and [observe] are mandatory. */
    class SpeechVerifierBuilder internal constructor() {

        private val config = SpeechVerifierConfig()
        private var observer: SpeechVerifierObserver? = null
        private var uiStateListener: ((SpeechVerifierUiState) -> Unit)? = null

        // Answers supplied via identityAnswers(...). Held on the builder (not the entry-point
        // object) until build() commits it, so it never leaks between two flows and is not a
        // Bundled field. null → identity questions fall back to the documents-endpoint fetch.
        private var identityAnswers: CustomerProfile? = null

        // Remote-logging opt-in; committed to SpeechVerifier.loggingEnabled by build(). OFF default.
        private var remoteLoggingEnabled: Boolean = false

        fun documentType(documentType: String) = apply { docType = documentType }

        /**
         * Enables SOFT remote logging of the verification flow — lightweight process signposts
         * (started / per-step outcome / succeeded / failed) and errors are posted, best-effort,
         * to the same `profile/client_logs` endpoint the core Amani SDK uses. It never blocks,
         * slows or crashes the flow; a failed post is silently dropped.
         *
         * **Disabled by default.** 
         */
        fun remoteLogging(enabled: Boolean) = apply { remoteLoggingEnabled = enabled }

        /**
         * Backend session used by [SpeechVerifier.upload]:
         *
         * @param serverURL the Amani API server, e.g. `https://server.example.com` (any of
         *   `host`, `https://host` or `https://host/api/v2/` forms are accepted).
         * @param token a **profile-scoped** JWT (the same token used to start the KYC
         *   session — it must carry the `profile_id` claim, otherwise the SSE result stream
         *   answers 403).
         *
         * The values are held in memory only (never written into the fragment's Bundle) and
         * never logged. Optional if you don't call [SpeechVerifier.upload].
         */
        @Throws(Exception::class)
        fun session(serverURL: String, token: String) = apply {
            if (serverURL.isBlank()) throw Exception("IllegalArgument: serverURL cannot be blank")
            if (token.isBlank()) throw Exception("IllegalArgument: token cannot be blank")
            serverUrl = serverURL
            sessionToken = token
        }

        /**
         * Enables the optional Voice Assistant (TTS): one prompt is played at the start of each
         * verification step. Local switch — default OFF. When on, also supply [voiceUrl]. Turning
         * it off (or omitting the URL) leaves the verification flow completely unchanged.
         */
        fun voiceAssistant(enabled: Boolean) = apply { config.voiceAssistantEnabled = enabled }

        /**
         * Voice Assistant base URL used to load the TTS voices. Provide the value read from the
         * app config's `ttsVoices` field. Only used when [voiceAssistant] is enabled; held in
         * memory only (never written into the fragment's Bundle).
         */
        fun voiceUrl(url: String) = apply { voiceUrl = url }

        @Throws(Exception::class)
        fun speechText(text: String) = apply {
            if (text.isBlank()) throw Exception("IllegalArgument: speechText cannot be blank")
            config.speechText = text
        }

        /**
         * The ORDERED verification flow: a mix of spoken-passphrase steps and knowledge-based
         * identity questions. The list order is the order the user experiences, and a step
         * repeated N times runs N times (each run re-randomises its own pick). All steps share
         * one continuous camera/video session; the whole flow succeeds only after the last step.
         *
         * ```kotlin
         * .verificationSteps(listOf(
         *     VerificationStep.SpokenText.of("Onaylıyorum", "Onay veriyorum"),
         *     VerificationStep.SpokenText.of("Onaylıyorum", "Onay veriyorum"),
         *     VerificationStep.IdentityQuestion.of(IdentityQuestionType.ID_NUMBER,
         *                                           IdentityQuestionType.MOTHER_NAME),
         *     VerificationStep.IdentityQuestion.of(IdentityQuestionType.FATHER_NAME),
         * ))
         * ```
         *
         * `IdentityQuestion` steps need a profile source — either [identityAnswers] (answers
         * provided up-front, no request) or [session] (fetched from the backend). Overrides the
         * simple [speechText] API.
         */
        @Throws(Exception::class)
        fun verificationSteps(steps: List<VerificationStep>) = apply {
            if (steps.isEmpty())
                throw Exception("IllegalArgument: verificationSteps cannot be empty")
            steps.forEach { step ->
                when (step) {
                    is VerificationStep.SpokenText -> {
                        if (step.phrases.isEmpty() || step.phrases.any { it.text.isBlank() })
                            throw Exception("IllegalArgument: SpokenText phrases cannot be empty/blank")
                    }
                    is VerificationStep.IdentityQuestion -> {
                        if (step.questions.isEmpty())
                            throw Exception("IllegalArgument: IdentityQuestion questions cannot be empty")
                    }
                }
            }
            config.steps = steps
        }

        /**
         * Supplies the identity-question answers DIRECTLY, so the `IdentityQuestion` steps verify
         * against these values instead of fetching them from the customer's `documents` endpoint.
         * No network round-trip is made for the profile when this is set (and `onPreparing()` is
         * not fired — there is nothing to wait for).
         *
         * Each argument backs one [IdentityQuestionType]; pass only the ones your configured
         * questions use (the rest may be left null). At least one non-blank value is required.
         * A question whose backing answer is missing/blank here behaves exactly as it does with a
         * fetched profile: it is dropped from that step's random pool, and if a step ends up with
         * no eligible question the flow reports it via [SpeechVerifierObserver.onError].
         *
         * ```kotlin
         * SpeechVerifier.Builder()
         *     .verificationSteps(listOf(
         *         VerificationStep.SpokenText.of("Onaylıyorum"),
         *         VerificationStep.IdentityQuestion.of(IdentityQuestionType.ID_NUMBER,
         *                                              IdentityQuestionType.MOTHER_NAME),
         *     ))
         *     // answers provided up-front → no request for customer detail is made
         *     .identityAnswers(idNumber = "12345678901", motherName = "AYŞE")
         *     .observe(myObserver)
         *     .build()
         * ```
         *
         * When set, this takes priority over the documents-endpoint fetch, so `IdentityQuestion`
         * steps no longer require [session] (though [session] is still needed to call
         * [SpeechVerifier.upload]). The values are held in memory only — never written into the
         * fragment's Bundle — and never logged.
         *
         * @param idNumber national ID number ([IdentityQuestionType.ID_NUMBER]); the WHOLE
         *   number is asked, digit by digit. Needs at least one digit to be usable.
         * @param motherName mother's given name ([IdentityQuestionType.MOTHER_NAME]).
         * @param fatherName father's given name ([IdentityQuestionType.FATHER_NAME]).
         * @param documentNumber document/serial number ([IdentityQuestionType.DOCUMENT_NUMBER]);
         *   its digits are read one by one.
         */
        @JvmOverloads
        @Throws(Exception::class)
        fun identityAnswers(
            idNumber: String? = null,
            motherName: String? = null,
            fatherName: String? = null,
            documentNumber: String? = null,
        ) = apply {
            val profile = CustomerProfile(
                idCardNumber = idNumber?.takeIf { it.isNotBlank() },
                motherName = motherName?.takeIf { it.isNotBlank() },
                fatherName = fatherName?.takeIf { it.isNotBlank() },
                documentNumber = documentNumber?.takeIf { it.isNotBlank() },
            )
            if (profile.idCardNumber == null && profile.motherName == null &&
                profile.fatherName == null && profile.documentNumber == null
            ) throw Exception(
                "IllegalArgument: identityAnswers(...) needs at least one non-blank answer"
            )
            identityAnswers = profile
        }

        /** Overrides the on-screen prompts of the identity questions (defaults are Turkish). */
        fun continuationPrompts(prompts: ContinuationPrompts) = apply {
            config.continuationPrompts = prompts
        }

        /**
         * Target words that are SHOWN on screen but EXCLUDED from verification — brand names
         * and foreign terms the bundled Turkish model cannot transcribe faithfully (e.g.
         * listOf("Bybit")). Acronyms and obviously non-Turkish words are already auto-exempted
         * when [autoDetectForeignWords] is on; this list is the deterministic override.
         */
        @Throws(Exception::class)
        fun verificationExemptWords(words: List<String>) = apply {
            if (words.any { it.isBlank() })
                throw Exception("IllegalArgument: verificationExemptWords cannot contain blank items")
            config.verificationExemptWords = words.toList()
        }

        /**
         * When enabled (default), target words that don't follow Turkish orthography/
         * phonotactics (q/w/x letters, initial consonant clusters like "Bybit", vowel-less
         * acronyms like "TR") are automatically EXCLUDED from verification. Disable for
         * strict verification of every word.
         */
        fun autoDetectForeignWords(enabled: Boolean) = apply {
            config.autoDetectForeignWords = enabled
        }

        /**
         * When enabled (default), an added Turkish NEGATION fails the step regardless of the
         * similarity threshold. Turkish negates with the tiny infix -ma/-me ("onaylıyorum" →
         * "onaylamıyorum", "veriyorum" → "vermiyorum"), which a fuzzy match would otherwise
         * accept — a semantic inversion of a consent text. Disable only if your target texts are
         * themselves negative. Use [rejectWords] for negatives this guard doesn't cover.
         */
        fun detectTurkishNegation(enabled: Boolean) = apply {
            config.detectTurkishNegation = enabled
        }

        /**
         * Words or phrases that make the step FAIL immediately if the user says them, regardless
         * of similarity (e.g. `listOf("hayır", "reddediyorum", "iptal", "onaylamıyorum")`). Matched
         * phonetically and case-insensitively. Complements the automatic [detectTurkishNegation]
         * guard for negatives/forms it doesn't cover. Blank items are rejected.
         */
        @Throws(Exception::class)
        fun rejectWords(words: List<String>) = apply {
            if (words.any { it.isBlank() })
                throw Exception("IllegalArgument: rejectWords cannot contain blank items")
            config.rejectWords = words.toList()
        }

        /**
         * When enabled, Turkish-specific letters are folded to their ASCII base — dropping the
         * cedilla, breve, dot and circumflex (ş→s, ç→c, ğ→g, ı/İ→i, ö→o, ü→u, â/î/û→a/i/u) — on
         * BOTH the on-screen target and the transcription before matching. Useful when the
         * transcription may drop the Turkish marks ("bes" for "beş"). Disabled by default
         * (strict Turkish matching).
         */
        fun ignoreTurkishDiacritics(enabled: Boolean) = apply {
            config.ignoreTurkishDiacritics = enabled
        }

        /**
         * Time window (in milliseconds) the user has to pass verification. If the passphrase is
         * not matched within this window, the flow fails and the retry screen is shown.
         * Default 60_000 (1 minute).
         */
        fun timeoutMillis(millis: Long) = apply {
            if (millis > 0) config.timeoutMs = millis
        }

        /**
         * Top corner radius (in dp) of the bottom sheet panel that sits behind the texts. The
         * identity-question progress loader is pinned to the top of this sheet. Default 0 (square
         * corners); pass e.g. 28f for a rounded bottom-sheet look.
         */
        fun bottomSheetCornerRadius(dp: Float) = apply {
            if (dp >= 0f) config.bottomSheetCornerRadiusDp = dp
        }

        /**
         * Overrides the screen colours using Android colour **resource ids** (`@ColorRes`, e.g.
         * `R.color.my_colour`). Pass only the ones you want to change; the rest keep the module
         * defaults. Use [userInterfaceColorInts] instead if your colours are raw ARGB/hex values
         * (e.g. coming from a remote config) — the two can be combined and the last write wins.
         */
        fun userInterfaceColors(
            @ColorRes overlayBackgroundColor: Int? = null,
            @ColorRes scrimColor: Int? = null,
            @ColorRes speechTextColor: Int? = null,
            @ColorRes speechTextHighlightColor: Int? = null,
            @ColorRes instructionTextColor: Int? = null,
            @ColorRes statusTextColor: Int? = null,
            @ColorRes micActiveColor: Int? = null,
            @ColorRes micIdleColor: Int? = null,
            @ColorRes resultSuccessColor: Int? = null,
            @ColorRes resultErrorColor: Int? = null,
            @ColorRes failedTextColor: Int? = null,
            @ColorRes retryButtonTextColor: Int? = null,
            @ColorRes retryButtonBackgroundColor: Int? = null,
            @ColorRes progressColor: Int? = null,
            @ColorRes progressTrackColor: Int? = null,
        ) = applyColors(
            raw = false,
            overlayBackgroundColor, scrimColor, speechTextColor, speechTextHighlightColor,
            instructionTextColor, statusTextColor, micActiveColor, micIdleColor,
            resultSuccessColor, resultErrorColor, failedTextColor,
            retryButtonTextColor, retryButtonBackgroundColor, progressColor, progressTrackColor,
        )

        /**
         * Overrides the screen colours using raw **`@ColorInt` ARGB** values (e.g. a hex colour
         * such as `Color.parseColor("#CC000000")` or `0xCC000000.toInt()` coming straight from a
         * remote config — no need to turn it into an Android resource first). Pass only the ones
         * you want to change; the rest keep the module defaults. Use [userInterfaceColors] instead
         * if your colours are `@ColorRes` resource ids; the two can be combined and last write wins.
         */
        fun userInterfaceColorInts(
            @ColorInt overlayBackgroundColor: Int? = null,
            @ColorInt scrimColor: Int? = null,
            @ColorInt speechTextColor: Int? = null,
            @ColorInt speechTextHighlightColor: Int? = null,
            @ColorInt instructionTextColor: Int? = null,
            @ColorInt statusTextColor: Int? = null,
            @ColorInt micActiveColor: Int? = null,
            @ColorInt micIdleColor: Int? = null,
            @ColorInt resultSuccessColor: Int? = null,
            @ColorInt resultErrorColor: Int? = null,
            @ColorInt failedTextColor: Int? = null,
            @ColorInt retryButtonTextColor: Int? = null,
            @ColorInt retryButtonBackgroundColor: Int? = null,
            @ColorInt progressColor: Int? = null,
            @ColorInt progressTrackColor: Int? = null,
        ) = applyColors(
            raw = true,
            overlayBackgroundColor, scrimColor, speechTextColor, speechTextHighlightColor,
            instructionTextColor, statusTextColor, micActiveColor, micIdleColor,
            resultSuccessColor, resultErrorColor, failedTextColor,
            retryButtonTextColor, retryButtonBackgroundColor, progressColor, progressTrackColor,
        )

        /**
         * Shared writer for both colour setters. Each non-null value is stored on [config.uiColors]
         * and its per-field kind flag is set ([raw] = true → raw `@ColorInt`) or cleared
         * ([raw] = false → `@ColorRes` id), so the fragment resolves each colour unambiguously.
         */
        private fun applyColors(
            raw: Boolean,
            overlayBackgroundColor: Int?,
            scrimColor: Int?,
            speechTextColor: Int?,
            speechTextHighlightColor: Int?,
            instructionTextColor: Int?,
            statusTextColor: Int?,
            micActiveColor: Int?,
            micIdleColor: Int?,
            resultSuccessColor: Int?,
            resultErrorColor: Int?,
            failedTextColor: Int?,
            retryButtonTextColor: Int?,
            retryButtonBackgroundColor: Int?,
            progressColor: Int?,
            progressTrackColor: Int?,
        ) = apply {
            val c = config.uiColors
            fun set(bit: Int, value: Int?, assign: (Int) -> Unit) {
                if (value == null) return
                assign(value)
                c.rawColorFlags = if (raw) c.rawColorFlags or (1 shl bit)
                else c.rawColorFlags and (1 shl bit).inv()
            }
            set(SpeechVerifierUIColors.BIT_OVERLAY, overlayBackgroundColor) { c.overlayBackgroundColor = it }
            set(SpeechVerifierUIColors.BIT_SCRIM, scrimColor) { c.scrimColor = it }
            set(SpeechVerifierUIColors.BIT_SPEECH_TEXT, speechTextColor) { c.speechTextColor = it }
            set(SpeechVerifierUIColors.BIT_SPEECH_HIGHLIGHT, speechTextHighlightColor) { c.speechTextHighlightColor = it }
            set(SpeechVerifierUIColors.BIT_INSTRUCTION, instructionTextColor) { c.instructionTextColor = it }
            set(SpeechVerifierUIColors.BIT_STATUS, statusTextColor) { c.statusTextColor = it }
            set(SpeechVerifierUIColors.BIT_MIC_ACTIVE, micActiveColor) { c.micActiveColor = it }
            set(SpeechVerifierUIColors.BIT_MIC_IDLE, micIdleColor) { c.micIdleColor = it }
            set(SpeechVerifierUIColors.BIT_RESULT_SUCCESS, resultSuccessColor) { c.resultSuccessColor = it }
            set(SpeechVerifierUIColors.BIT_RESULT_ERROR, resultErrorColor) { c.resultErrorColor = it }
            set(SpeechVerifierUIColors.BIT_FAILED_TEXT, failedTextColor) { c.failedTextColor = it }
            set(SpeechVerifierUIColors.BIT_RETRY_TEXT, retryButtonTextColor) { c.retryButtonTextColor = it }
            set(SpeechVerifierUIColors.BIT_RETRY_BG, retryButtonBackgroundColor) { c.retryButtonBackgroundColor = it }
            set(SpeechVerifierUIColors.BIT_PROGRESS, progressColor) { c.progressColor = it }
            set(SpeechVerifierUIColors.BIT_PROGRESS_TRACK, progressTrackColor) { c.progressTrackColor = it }
        }

        fun userInterfaceTexts(
            instruction: String? = null,
            listening: String? = null,
            verifying: String? = null,
            verified: String? = null,
            failed: String? = null,
            recognizerNotAvailable: String? = null,
            retry: String? = null,
        ) = apply {
            config.uiTexts.also {
                if (instruction != null) it.instruction = instruction
                if (listening != null) it.listening = listening
                if (verifying != null) it.verifying = verifying
                if (verified != null) it.verified = verified
                if (failed != null) it.failed = failed
                if (recognizerNotAvailable != null) it.recognizerNotAvailable = recognizerNotAvailable
                if (retry != null) it.retry = retry
            }
        }

        @Throws(Exception::class)
        fun observe(observer: SpeechVerifierObserver?) = apply {
            if (observer == null) throw Exception("NullPointerException: Observer cannot be null")
            this.observer = observer
        }

        fun onUiStateChanged(listener: (SpeechVerifierUiState) -> Unit) = apply {
            this.uiStateListener = listener
        }

        @Throws(Exception::class)
        fun build(): Fragment {
            // Normalise to a single source of truth: the ordered steps list. The simple
            // speechText(...) API becomes one SpokenText step.
            if (config.steps.isEmpty()) {
                if (config.speechText.isBlank())
                    throw Exception(
                        "IllegalState: speechText(...) or verificationSteps(...) must be set before build()"
                    )
                config.steps = listOf(VerificationStep.SpokenText.of(config.speechText))
            }
            // IdentityQuestion steps need a profile source: either answers provided up-front via
            // identityAnswers(...), or session(serverURL, token) to fetch them from the backend.
            if (config.steps.any { it is VerificationStep.IdentityQuestion } &&
                identityAnswers == null &&
                (serverUrl.isNullOrBlank() || sessionToken.isNullOrBlank())
            ) {
                throw Exception(
                    "IllegalState: IdentityQuestion steps require identityAnswers(...) or " +
                            "session(serverURL, token)"
                )
            }
            val obs = observer
                ?: throw Exception("IllegalState: observe(...) must be set before build()")

            operationID = UUID.randomUUID().toString()
            lastSecuredVideoPath = null // new session — a stale recording must never be uploaded
            providedProfile = identityAnswers // commit this builder's answers (or null → fetch)
            loggingEnabled = remoteLoggingEnabled // commit the opt-in for this flow

            val args = Bundle().apply { putParcelable(SpeechVerifierFragment.KEY_CONFIG, config) }
            return SpeechVerifierFragment().also {
                it.arguments = args
                it.observer = obs
                it.uiStateListener = uiStateListener
            }
        }
    }
}
