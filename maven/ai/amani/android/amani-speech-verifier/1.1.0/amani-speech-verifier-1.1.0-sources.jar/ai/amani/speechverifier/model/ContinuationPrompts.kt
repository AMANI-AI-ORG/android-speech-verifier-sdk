package ai.amani.speechverifier.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * On-screen prompts for the continuation (KBA) questions. Defaults are Turkish; override via
 * [ai.amani.speechverifier.SpeechVerifier.SpeechVerifierBuilder.continuationPrompts].
 *
 * @param instruction Small line shown above the question during the continuation phase.
 * @param idNumber    Prompt for the ID-number question (the whole number is asked). An
 *                    optional `%d` is replaced by the total digit count.
 * @param motherName  Prompt for the mother's-name question.
 * @param fatherName  Prompt for the father's-name question.
 * @param documentNumber Prompt for the document-number question.
 */
@Parcelize
data class ContinuationPrompts(
    var instruction: String = "Lütfen aşağıdaki soruyu sesli yanıtlayın",
    var idNumber: String = "Kimlik numaranızın tüm hanelerini tek tek söyleyin",
    var motherName: String = "Annenizin adını söyleyin",
    var fatherName: String = "Babanızın adını söyleyin",
    var documentNumber: String = "Belge numaranızın rakamlarını tek tek söyleyin",
) : Parcelable
