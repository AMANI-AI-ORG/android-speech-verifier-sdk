package ai.amani.speechverifier.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * One knowledge-based question in a [VerificationStep.IdentityQuestion] pool, with an optional
 * per-question similarity threshold. The module picks one at random per attempt (among the
 * types the customer profile can back).
 *
 * Threshold resolution (most specific wins):
 *  [thresholdPercent] → the flow default
 *  ([ai.amani.speechverifier.SpeechVerifier.SpeechVerifierBuilder.matchThresholdPercent]).
 *
 * @param type the question type asked.
 * @param thresholdPercent similarity (1..100) this question's spoken answer must reach; null
 *   falls back to the flow default.
 * @param successCaptureDelayMs per-question delay (ms) kept recording after this question's
 *   answer matches so the last digit/word is fully captured; null uses the module default.
 */
@Parcelize
data class IdentityQuestionSpec(
    val type: IdentityQuestionType,
    val thresholdPercent: Int = 80,
    val successCaptureDelayMs: Long = 1000
) : Parcelable
