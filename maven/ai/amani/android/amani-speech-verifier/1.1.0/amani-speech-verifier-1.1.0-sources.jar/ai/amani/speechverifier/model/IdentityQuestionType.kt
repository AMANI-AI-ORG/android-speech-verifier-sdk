package ai.amani.speechverifier.model

/**
 * The knowledge-based questions the identity-question step can ask. Each maps to a field
 * extracted from the customer's uploaded documents (fetched from the `documents` endpoint);
 * the SDK picks randomly among the types the integrator enables and that are present in the
 * response.
 */
enum class IdentityQuestionType {
    /** The WHOLE national ID number (IDNumber) — every digit, read one by one. */
    ID_NUMBER,

    /** Mother's given name (MotherName). */
    MOTHER_NAME,

    /** Father's given name (FatherName). */
    FATHER_NAME,

    /** The document/serial number (DocumentNumber) — its digits, read one by one. */
    DOCUMENT_NUMBER
}
