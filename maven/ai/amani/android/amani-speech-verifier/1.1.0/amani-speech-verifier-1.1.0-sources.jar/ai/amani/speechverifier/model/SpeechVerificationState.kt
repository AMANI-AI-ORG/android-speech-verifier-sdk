package ai.amani.speechverifier.model

/** Low-level phase of the recognition session, driving per-frame UI updates. */
enum class ListeningState {
    IDLE, LISTENING, VERIFYING, MATCHED, NOT_MATCHED, ERROR
}

/**
 * Complete UI state emitted every time a partial/final recognition result is processed.
 *
 * @param listeningState   Current phase.
 * @param recognizedText   Latest transcription received.
 * @param matchedWordCount Leading target words matched exactly so far (for live highlight).
 * @param totalWordCount   Word count of the target text.
 * @param progressPercent  Live 0..100 match progress (by matched target characters) for the
 *                         identity-question horizontal loader.
 * @param showProgress     True while an identity-question step is active — drives the loader's
 *                         visibility (spoken-text steps use the in-text highlight instead).
 */
data class SpeechVerificationState(
    val listeningState: ListeningState = ListeningState.IDLE,
    val recognizedText: String = "",
    val matchedWordCount: Int = 0,
    val totalWordCount: Int = 0,
    val progressPercent: Int = 0,
    val showProgress: Boolean = false
)
