package ai.amani.speechverifier.model

import ai.amani.speechverifier.R
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Colour overrides for the speech-verification screen.
 *
 * Each value may be EITHER a colour **resource id** (`@ColorRes`, e.g. `R.color.my_colour` —
 * the module defaults are `R.color.svf_*`) OR a raw **`@ColorInt` ARGB** value (e.g. a hex
 * colour such as `0xCC000000.toInt()` coming straight from a remote config). The screen
 * resolves both forms transparently, so an integrator can forward remote-config hex colours
 * without first turning them into Android resources.
 */
@Parcelize
data class SpeechVerifierUIColors(
    var overlayBackgroundColor: Int = R.color.svf_overlay,
    /** Low-opacity black scrim behind the texts. Use a colour with alpha to control opacity. */
    var scrimColor: Int = R.color.svf_scrim,
    var speechTextColor: Int = R.color.svf_white,
    var speechTextHighlightColor: Int = R.color.svf_green,
    var instructionTextColor: Int = R.color.svf_white,
    var statusTextColor: Int = R.color.svf_white,
    var micActiveColor: Int = R.color.svf_green,
    var micIdleColor: Int = R.color.svf_white,
    var resultSuccessColor: Int = R.color.svf_green,
    var resultErrorColor: Int = R.color.svf_red,
    /** Failure message text on the retry screen. */
    var failedTextColor: Int = R.color.svf_white,
    /** Retry button text + background — a high-contrast light button on the dark scrim. */
    var retryButtonTextColor: Int = R.color.svf_black,
    var retryButtonBackgroundColor: Int = R.color.svf_white,
    /** Identity-question progress loader: the filled portion. */
    var progressColor: Int = R.color.svf_progress,
    /** Identity-question progress loader: the unfilled track behind the fill. */
    var progressTrackColor: Int = R.color.svf_progress_track,

    /**
     * Per-field kind flags. A set bit means the same-indexed colour field holds a raw `@ColorInt`
     * (ARGB) value; a clear bit means it holds a `@ColorRes` resource id. Written by the builder
     * according to which setter was used (`userInterfaceColors` = resource ids,
     * `userInterfaceColorInts` = raw colours). Defaults to 0, so the module defaults (and any
     * value set the old way) are treated as resource ids — the original behaviour.
     */
    var rawColorFlags: Int = 0,
) : Parcelable {

    /** True when the field at [bit] holds a raw `@ColorInt` value rather than a `@ColorRes` id. */
    internal fun isRaw(bit: Int): Boolean = (rawColorFlags and (1 shl bit)) != 0

    internal companion object {
        const val BIT_OVERLAY = 0
        const val BIT_SCRIM = 1
        const val BIT_SPEECH_TEXT = 2
        const val BIT_SPEECH_HIGHLIGHT = 3
        const val BIT_INSTRUCTION = 4
        const val BIT_STATUS = 5
        const val BIT_MIC_ACTIVE = 6
        const val BIT_MIC_IDLE = 7
        const val BIT_RESULT_SUCCESS = 8
        const val BIT_RESULT_ERROR = 9
        const val BIT_FAILED_TEXT = 10
        const val BIT_RETRY_TEXT = 11
        const val BIT_RETRY_BG = 12
        const val BIT_PROGRESS = 13
        const val BIT_PROGRESS_TRACK = 14
    }
}
