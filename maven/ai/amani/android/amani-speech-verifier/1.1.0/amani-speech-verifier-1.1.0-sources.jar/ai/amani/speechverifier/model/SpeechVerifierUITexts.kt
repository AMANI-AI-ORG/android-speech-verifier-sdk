package ai.amani.speechverifier.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Text overrides for the speech-verification screen.
 *
 * @param instruction            Small instruction line above the passphrase.
 * @param listening              Status shown while listening.
 * @param verifying              Status shown while a result is being evaluated.
 * @param verified               Status shown on success.
 * @param failed                 Failure message shown when the time window elapses.
 * @param recognizerNotAvailable Shown when the offline engine/model is unavailable.
 * @param retry                  Label of the retry button shown on the failure screen.
 */
@Parcelize
data class SpeechVerifierUITexts(
    var instruction: String = "Please read the text below aloud",
    var listening: String = "Listening…",
    var verifying: String = "Verifying your speech…",
    var verified: String = "Speech verified",
    var failed: String = "Time is up — verification failed",
    var recognizerNotAvailable: String = "Speech recognition is not available on this device",
    var retry: String = "Try Again",
) : Parcelable
