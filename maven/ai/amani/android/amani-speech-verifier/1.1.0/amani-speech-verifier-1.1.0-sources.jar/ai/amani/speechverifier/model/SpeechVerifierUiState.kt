package ai.amani.speechverifier.model

/**
 * High-level UI states of the flow, delivered to the listener registered via
 * [ai.amani.speechverifier.SpeechVerifier.Builder.onUiStateChanged]. Main-thread only.
 */
enum class SpeechVerifierUiState {
    /** Camera opened and video recording of the session began. */
    CAPTURE_STARTED,

    /** The recognizer started listening to the microphone. */
    LISTENING_STARTED,

    /** The spoken text matched; recording is being finalised. */
    SPEECH_VERIFIED
}
