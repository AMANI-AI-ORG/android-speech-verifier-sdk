package ai.amani.speechverifier.model

/**
 * Failure reasons of [ai.amani.speechverifier.SpeechVerifier.upload], reported through
 * [ai.amani.speechverifier.observable.SpeechVerifierUploadObserver.onError].
 */
enum class SpeechVerifierUploadError(val code: Int) {

    /** `Builder.session(serverURL, token)` was never provided (or the video file is gone). */
    SESSION_MISSING(9100),

    /** The document POST failed — network error or non-2xx HTTP response. */
    UPLOAD_FAILED(9101),

    /**
     * The SSE stream rejected the credentials (401/403) — the JWT is invalid/expired or lacks
     * the profile scope (`profile_id` claim) the profile event stream requires.
     */
    SSE_AUTH_FAILED(9102),

    /** The upload succeeded but no correlated step status arrived within the timeout window. */
    RESULT_TIMEOUT(9103),

    /** The backend answered with a payload that could not be interpreted. */
    PARSE_ERROR(9104)
}
