package ai.amani.speechverifier.model

/**
 * Final outcome of [ai.amani.speechverifier.SpeechVerifier.upload].
 *
 * @property stepStatus the step status pushed by the backend over the SSE event stream once
 * it finished evaluating the uploaded document — e.g. `APPROVED`, `PENDING_REVIEW`,
 * `REJECTED`, `PROCESSING` (the value is delivered verbatim from the backend).
 * @property documentId id of the document created by the upload, when the backend returned one.
 */
data class SpeechVerifierUploadResult(
    val stepStatus: String,
    val documentId: String?
)
