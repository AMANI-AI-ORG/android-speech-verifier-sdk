package ai.amani.speechverifier.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * One passphrase in a [VerificationStep.SpokenText] pool, with an optional per-phrase
 * similarity threshold. The module picks one at random per attempt.
 *
 * Threshold resolution (most specific wins):
 *  [thresholdPercent] → the flow default
 *
 * @param text the phrase shown on screen and verified.
 * @param thresholdPercent whole-phrase similarity (1..100) the transcription must reach; null
 *   falls back to the flow default. The phrase passes when the AVERAGE similarity of its
 *   verifiable words reaches this.
 * @param successCaptureDelayMs per-phrase delay (ms) kept recording after this phrase matches so
 *   its last word is fully captured; null uses the module default.
 */
@Parcelize
data class SpokenPhrase(
    val text: String,
    val thresholdPercent: Int = 80,
    val successCaptureDelayMs: Long? = 1000
) : Parcelable
