package ai.amani.speechverifier.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * One step of the verification flow. The order of the list given to
 * [ai.amani.speechverifier.SpeechVerifier.SpeechVerifierBuilder.verificationSteps] IS the order
 * the user experiences, and a step repeated N times runs N times (each run re-randomises its
 * own pick). All steps share one continuous camera/video session.
 */
sealed class VerificationStep : Parcelable {

    /**
     * Read a passphrase aloud. One [SpokenPhrase] is picked at random from [phrases] for this
     * step (and re-picked on retry). Provide a single-item list for a fixed passphrase.
     *
     * Each phrase can carry its own similarity threshold — overall and even per word — see
     * [SpokenPhrase]. Use [of] for the common case of plain phrases that all use the flow's
     * default threshold.
     */
    @Parcelize
    data class SpokenText(val phrases: List<SpokenPhrase>) : VerificationStep() {
        companion object {
            /** Fixed phrases that all use the flow's default threshold (no per-phrase override). */
            fun of(texts: List<String>): SpokenText = SpokenText(texts.map { SpokenPhrase(it) })

            /** Fixed phrases that all use the flow's default threshold (no per-phrase override). */
            fun of(vararg texts: String): SpokenText = of(texts.toList())
        }
    }

    /**
     * Answer a knowledge-based question drawn from the customer's backend profile. One
     * [IdentityQuestionSpec] is picked at random from [questions] for this step (from the
     * types whose profile field is present), and re-picked on retry. Each question can carry
     * its own similarity threshold (see [IdentityQuestionSpec]). Requires
     * [ai.amani.speechverifier.SpeechVerifier.SpeechVerifierBuilder.session]. Use [of] for the
     * common case of plain question types that all use the flow's default threshold.
     */
    @Parcelize
    data class IdentityQuestion(val questions: List<IdentityQuestionSpec>) : VerificationStep() {
        companion object {
            /** Question types that all use the flow's default threshold (no per-question override). */
            fun of(types: List<IdentityQuestionType>): IdentityQuestion =
                IdentityQuestion(types.map { IdentityQuestionSpec(it) })

            /** Question types that all use the flow's default threshold (no per-question override). */
            fun of(vararg types: IdentityQuestionType): IdentityQuestion = of(types.toList())
        }
    }
}
