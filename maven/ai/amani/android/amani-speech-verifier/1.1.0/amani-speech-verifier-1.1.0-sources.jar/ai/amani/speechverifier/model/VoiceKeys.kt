package ai.amani.speechverifier.model

/**
 * Voice Assistant (TTS) prompt keys — one per verification-step kind. The Voice Assistant SDK
 * plays a single prompt (by key) once at the start of the matching step.
 *
 * These are placeholders: the real key strings are provided by the Amani team per voice
 * configuration and are not published yet. Kept here as constants in one shared place so they
 * can be swapped in a single edit once the actual keys are known.
 *
 * Mapping (5 voices):
 *  - [ID_NUMBER]       → identity step asking the national ID (TCKN); `ID_NUMBER` is the TCKN.
 *  - [MOTHER_NAME]     → identity step asking the mother's name.
 *  - [FATHER_NAME]     → identity step asking the father's name.
 *  - [DOCUMENT_NUMBER] → identity step asking the document/serial number.
 *  - [SPOKEN_TEXT]     → plain spoken-text step (e.g. "onaylıyorum" / "approve").
 */
internal object VoiceKeys {
    const val ID_NUMBER = "VOICE_ST0"        // "Kimlik numaranızı rakam rakam … okuyun" (TCKN)
    const val DOCUMENT_NUMBER = "VOICE_ST1"  // "Kimlik belge numaranızı rakam rakam … okuyun"
    const val MOTHER_NAME = "VOICE_ST2"      // "Annenizin adını … söyleyin"
    const val FATHER_NAME = "VOICE_ST3"      // "Babanızın adını … söyleyin"
    const val SPOKEN_TEXT = "VOICE_ST4"      // "Ekrandaki metni … okuyun"
}
