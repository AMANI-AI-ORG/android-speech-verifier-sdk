package ai.amani.speechverifier.observable

/** Failure reasons of the speech-verification flow, each with a stable numeric code. */
enum class OnFailureSpeechVerifier(val code: Int) {
    /** The completed utterance did not match the displayed text. */
    SPEECH_NOT_MATCHED(9000),

    /** No usable speech was detected before the recognizer timed out. */
    SPEECH_NOT_DETECTED(9001),

    /** The verification time window elapsed without a successful match. */
    VERIFICATION_TIMEOUT(9002),

    /**
     * The utterance was a NEGATION or a configured reject word — a semantic inversion of the
     * expected text (e.g. "onaylamıyorum" instead of "onaylıyorum"). Failed on purpose regardless
     * of similarity, because threshold matching alone would let the negative form through.
     */
    SPEECH_NEGATION_DETECTED(9003)
}
