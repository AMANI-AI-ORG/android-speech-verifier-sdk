package ai.amani.speechverifier.observable

/** Callbacks of the speech-verification flow. Register via SpeechVerifier.Builder.observe. */
interface SpeechVerifierObserver {

    /**
     * A blocking preparation step started — currently the customer-profile fetch that backs the
     * identity questions. Fired on the main thread only when there is something to wait for
     * (i.e. an IdentityQuestion step is configured); paired with [onReady]. Use it to show a
     * loader. Default no-op.
     */
    fun onPreparing() {}

    /**
     * The screen is ready for the user: permissions are granted, the camera is bound and — when
     * identity questions are configured — the customer profile has been fetched and the
     * questions prepared. Always fired on the main thread, before the first prompt is shown.
     * Pairs with [onPreparing]; hide any loader here. Default no-op.
     */
    fun onReady() {}

    /**
     * Verification succeeded and the session video has been recorded and secured. When the
     * continuation flow is configured, this fires only after ALL steps (passphrase + every
     * knowledge-based question) passed. No data is returned on purpose — the answers stay
     * inside the module; the recording is tracked internally for
     * [ai.amani.speechverifier.SpeechVerifier.upload].
     */
    fun onSuccess()

    /**
     * A completed utterance did not match.
     * @param currentAttempt Number of failed attempts so far in this session.
     */
    fun onFailure(reason: OnFailureSpeechVerifier, currentAttempt: Int)

    /** A non-recoverable error occurred (recognizer/recording failure). */
    fun onError(error: Error)
}
