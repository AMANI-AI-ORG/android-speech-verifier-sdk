package ai.amani.speechverifier.observable

import ai.amani.speechverifier.model.SpeechVerifierUploadError
import ai.amani.speechverifier.model.SpeechVerifierUploadResult

/**
 * Result callback of [ai.amani.speechverifier.SpeechVerifier.upload]. Both methods are always
 * invoked on the main thread.
 */
interface SpeechVerifierUploadObserver {

    /**
     * The video was uploaded and the backend pushed the step's evaluation status over the SSE
     * event stream. [SpeechVerifierUploadResult.stepStatus] carries that status verbatim
     * (e.g. `APPROVED`, `PENDING_REVIEW`, `REJECTED`).
     */
    fun onResult(result: SpeechVerifierUploadResult)

    /** The upload (or the wait for its evaluation) failed. */
    fun onError(error: SpeechVerifierUploadError, message: String)
}
